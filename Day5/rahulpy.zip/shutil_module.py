import shutil as sh

#  Copy file from source to destination
#sh.copy(r"C:\Users\yathish.l@lilly.com\Downloads\Day5\Day5/rahulpy",r"C:\Users\yathish.l@lilly.com\Downloads\Day5")

#  Move file from source to destination

#sh.move(r"C:\Users\yathish.l@lilly.com\Downloads\Day5\Day5/rahulpy",r"C:\Users\yathish.l@lilly.com\Downloads\Day5")
# Zip and unzip a file
sh.make_archive(r"C:\Users\yathish.l@lilly.com\Downloads\Day5\Day5/rahulpy","zip")